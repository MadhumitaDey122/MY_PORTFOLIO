// Loader
window.addEventListener('load', () => { 
  document.getElementById('loader').style.display = 'none'; 
});

// AOS
AOS.init({ duration: 1000, once: true, offset: 100 });

// Typed.js
new Typed('#typed-text', { 
  strings: ['Frontend Developer', 'Data Analytics', 'Software Developer'], 
  typeSpeed: 80, backSpeed: 50, loop: true 
});

// Theme Toggle
document.getElementById('themeToggle').onclick = () => {
  const html = document.documentElement;
  html.dataset.theme = html.dataset.theme === 'dark' ? 'light' : 'dark';
  document.querySelector('#themeToggle i').className = 
    html.dataset.theme === 'dark' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
};

// Scroll to Top + Animate on Scroll
window.onscroll = () => {
  document.getElementById('scrollTop').style.display = window.scrollY > 300 ? 'block' : 'none';
  
  document.querySelectorAll('.progress-bar').forEach(bar => {
    if(bar.getBoundingClientRect().top < window.innerHeight - 100) {
      bar.style.width = bar.dataset.width;
    }
  });
};

document.getElementById('scrollTop').onclick = () => 
  window.scrollTo({top: 0, behavior: 'smooth'});

// Counter Animation
const counters = document.querySelectorAll('.counter');
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if(entry.isIntersecting) {
      let counter = entry.target; 
      let target = +counter.dataset.target; 
      let count = 0;
      let timer = setInterval(() => { 
        count++; 
        counter.innerText = count; 
        if(count >= target) clearInterval(timer); 
      }, 50);
    }
  });
});
counters.forEach(c => observer.observe(c));

// Contact Form
document.getElementById('contactForm').addEventListener('submit', e => { 
  e.preventDefault(); 
  alert('Message Sent Successfully! I will get back to you soon. ✅'); 
  e.target.reset();
});