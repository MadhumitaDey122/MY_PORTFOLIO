<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Chandi - Senior Frontend Developer & UI/UX Designer Portfolio">
  <meta name="keywords" content="Frontend Developer, UI UX Designer, React, JavaScript, Portfolio">
  <meta name="author" content="Chandi">
  <title>Portfolio</title>
  
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- AOS Animation -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  
  <!-- Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  
  <!-- Custom CSS -->
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- LOADING ANIMATION -->
  <div id="loader">
    <div class="loader-circle"></div>
  </div>

  <!-- NAVBAR -->
  <nav class="navbar navbar-expand-lg glass-nav fixed-top">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#home">MY SITE<span class="gradient-text">.</span></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <i class="fa-solid fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="#skills">Skills</a></li>
          <li class="nav-item"><a class="nav-link" href="#projects">Projects</a></li>
          <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
          <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
        </ul>
        <button id="themeToggle" class="btn theme-btn ms-3"><i class="fa-solid fa-moon"></i></button>
      </div>
    </div>
</nav>

  <!-- 1. HOME -->
  <section id="home" class="hero-section">
    <div class="particles"></div>
    <div class="container">
      <div class="row align-items-center min-vh-100">
        <div class="col-lg-6" data-aos="fade-right">
          <h4 class="greeting">Hello, I'm</h4>
          <h1 class="hero-name">MADHUMITA DEY</h1>
          <h2 class="hero-role">I'm a <span id="typed-text"></span></h2>
          <p class="hero-desc">Crafting beautiful, high-performance web experiences with modern technologies. I turn ideas into stunning digital products.</p>
          <div class="hero-btns">
            <a href="RESUME MADHUMITA DEY.pdf" class="btn btn-gradient" download><i class="fa fa-download"></i> Download Resume</a>
            <a href="#contact" class="btn btn-outline-gradient">Hire Me</a>
          </div>
          <div class="social-icons mt-4">
            <div class="social-icons mt-4">
  <a href="https://github.com/MadhumitaDey122" target="_blank"><i class="fab fa-github"></i></a>
  <a href="https://www.linkedin.com/in/madhumita-dey-ab2091341" target="_blank"><i class="fab fa-linkedin"></i></a>
  <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
  <a href="https://www.instagram.com/_____miss__dey______?igsh=Mnd6aHkxdHJtbmNy" target="_blank"><i class="fab fa-instagram"></i></a>
</div>
          </div>
        </div>
        <div class="col-lg-6 text-center" data-aos="fade-left">
          <div class="profile-wrapper">
            <img src="Profile photo.jpeg" alt="Chandi" class="profile-img">
            <div class="profile-bg"></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 2. ABOUT -->
  <section id="about" class="section-padding">
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">About Me</h2>
      <div class="row g-4">
        <div class="col-lg-6" data-aos="fade-right">
          <div class="glass-card">
            <h4><i class="fa fa-user"></i> Introduction</h4>
            <p class="job-company">I'm a passionate Frontend Developer.</p>
          </div>
          <div class="glass-card mt-4">
            <h4><i class="fa fa-bullseye"></i> Career Objective</h4>
            <p class="job-company">Complite a intranship Project in Cognifyz</p>
          </div>
          <div class="glass-card mt-4">
            <h4><i class="fa fa-graduation-cap"></i> Education</h4>
              <h6>Diploma - Computer Science & Enginering</h6>
              <p class="job-company">Gomati District Polytechnic | 2023 - 2026</p>
              <p class="job-company">CGPA: 6.65</p>
            </div>
        </div>
        <div class="col-lg-6" data-aos="fade-left">
          <div class="glass-card">
            <h4><i class="fa fa-graduation-cap"></i> Education</h4>
            <div class="timeline-item">
              <h6>B.Tech - Computer Science</h6>
              <p class="job-company">Techo Bengal Institute Of Technology | 2023 - 2026</p>
              <p class="job-company">CGPA: 6.99</p>
            </div>
            
          </div>
          <div class="glass-card mt-4">
            <h4><i class="fa fa-briefcase"></i> Experience</h4>
            <div class="timeline-item">
              <h6><strong>Frontend Intern</strong></h6>
              <p class="job-company">Cognifyz Technologies | 2026</p>
              <p class="job-company">Built 8 responsive projects using HTML, CSS, JS, Bootstrap & API integration.</p>
            </div>
            <div class="timeline-item">
              <h6 class="job-tile"><strong>Web Development Intern</strong></h6>
              <p class="job-company">Internship: NIELIT Agartala | 2021</p>
              <p class="job-company">●Built static web pages using HTML and CSS</p>
              <p class="job-company">●Understood webpage layout structuring and styling basics</p>
            </div>
            <div class="timeline-item">
              <h6><strong>Industrial IoT Intern</strong></h6>
              <p class="job-company">Technomate Edubotics | 2022</p>
              <p class="job-company">● Worked with microcontrollers and IoT sensors</p> 
            <p class="job-company">● Built small automation prototypes using ESP boards and Arduino IDE </p> 
            <p class="job-company">● Learned real-world application of IoT in home automation </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 3. SKILLS -->
  <section id="skills">
  <h2>Technical Skills</h2>
  <div class="skills-container">

    <!-- Programming -->
    <div class="skill-card">
      <div class="skill-header">
        <div class="skill-icon">💻</div>
        <h3>Programming</h3>
      </div>
      <div class="skill-tags">
        <span>Python</span>
        <span>Java</span>
        <span>C</span>
        <span>Data Structures & Algorithms</span>
      </div>
    </div>

    <!-- FrontEnd -->
    <div class="skill-card">
      <div class="skill-header">
        <div class="skill-icon">🎨</div>
        <h3>FrontEnd</h3>
      </div>
      <div class="skill-tags">
        <span>HTML</span>
        <span>CSS</span>
        <span>JavaScript</span>
        <!-- <span>React JS</span>
        <span>Tailwind CSS</span>
         <span>Basic UI/UX principles</span>-->
      </div>
    </div>

    <!-- BackEnd -->
    <div class="skill-card">
      <div class="skill-header">
        <div class="skill-icon">⚙️</div>
        <h3>BackEnd</h3>
      </div>
      <div class="skill-tags">
        <span>PHP</span>
        <span>MySQL</span>
        <!--<span>Flask</span>
        <span>Django</span>-->
        <span>SQL</span>
      </div>
    </div>

    <!-- AI -->
    <!--<div class="skill-card">
      <div class="skill-header">
        <div class="skill-icon">🧠</div>
        <h3>AI</h3>
      </div>
      <div class="skill-tags">
        <span>Machine Learning</span>
        <span>Python</span>
        <span>Data Analysis</span>
      </div>
    </div>-->

  </div>
</section>

  <!-- 4. PROJECTS -->
  <section id="projects" class="section-padding">
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">Featured Projects</h2>
      <div class="row g-4">
        <div class="col-md-6 col-lg-3" data-aos="zoom-in">
          <div class="project-card glass-card">
            <img src="Interior.jpg" alt="Smart Traffic">
            <h5>Interior Desing</h5>
            <p>Interior Desing Weabsite .</p>
            <div class="tech-stack"><span>HTML</span><span>CSS</span><span>JavaScript</span></div>
            <div class="project-btns">
              <a href="#" class="btn btn-sm btn-gradient">GitHub</a>
              <a href="#" class="btn btn-sm btn-outline-gradient">Live Demo</a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="100">
          <div class="project-card glass-card">
            <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400" alt="Women Safety">
            <h5>Smart Wearable Self-Defense & Emergency Alert System</h5>
            <p>Wearable device with emergency SOS, live location tracking and alert system.</p>
            <div class="tech-stack"><span>Arduino IDE </span><span>Sensor</span><span>GSM Module </span><span>GPS Module </span></div>
            <div class="project-btns">
              <a href="#" class="btn btn-sm btn-gradient">GitHub</a>
              <a href="#" class="btn btn-sm btn-outline-gradient">Live Demo</a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="200">
          <div class="project-card glass-card">
            <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400" alt="Portfolio">
            <h5>Portfolio Website</h5>
            <p>Premium glassmorphism portfolio with dark/light mode and animations.</p>
            <div class="tech-stack"><span>HTML</span><span>CSS</span><span>JS</span></div>
            <div class="project-btns">
              <a href="#" class="btn btn-sm btn-gradient">GitHub</a>
              <a href="#" class="btn btn-sm btn-outline-gradient">Live Demo</a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="300">
          <div class="project-card glass-card">
            <img src="E-Comerce.jpg" alt="E-commerce">
            <h5>E-commerce Website</h5>
            <p>Full-stack MERN e-commerce with cart, payment gateway and admin panel.</p>
            <div class="tech-stack"><span>MERN</span><span>Stripe</span><span>Redux</span></div>
            <div class="project-btns">
              <a href="#" class="btn btn-sm btn-gradient">GitHub</a>
              <a href="#" class="btn btn-sm btn-outline-gradient">Live Demo</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 5. SERVICES -->
  <section id="services" class="section-padding">
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">My Services</h2>
      <div class="row g-4">
        <div class="col-md-4" data-aos="fade-up">
          <div class="service-card glass-card text-center">
            <i class="fa fa-code service-icon"></i>
            <h5>Web Development</h5>
            <p>Custom responsive websites built with React, Next.js and modern frameworks.</p>
          </div>
        </div>
        <!-- <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
          <div class="service-card glass-card text-center">
            <i class="fa fa-paintbrush service-icon"></i>
            <h5>UI/UX Design</h5>
            <p>User-centered designs in Figma with prototyping and design systems.</p>
          </div>
        </div> -->
        <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
          <div class="service-card glass-card text-center">
            <i class="fas fa-microchip"></i>
            <h5>IoT</h5>
            <p>I design and develop IoT systems that connect devices to the cloud. Experienced in working with sensors, microcontrollers, and real-time data visualization to build smart, efficient solutions</p>
          </div>
        </div>
        <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
          <div class="service-card glass-card text-center">
            <i class="fa fa-mobile service-icon"></i>
            <h5>Data Analytics</h5>
            <p>I turn raw data into actionable insights. I work with Python, SQL, Excel, and Power BI to analyze trends, build dashboards, and support data-driven decisions.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 6. RESUME TIMELINE -->
  <section id="resume" class="section-padding">
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">Resume Timeline</h2>
      <div class="timeline">
        <div class="timeline-item glass-card" data-aos="fade-right">
          <span class="timeline-date">2026</span>
          <h5>Frontend Intern - Cognifyz Technologies</h5>
          <p class="job-company">Developed web applications with API integration.</p>
        </div>
        <div class="timeline-item glass-card" data-aos="fade-left">
          <span class="timeline-date">2021</span>
          <h5>Web Development Intern</h5>
          <p class="job-company">Internship: NIELIT Agartala | 2021</p>
              <p class="job-company">●Built static web pages using HTML and CSS</p>
              <p class="job-company">●Understood webpage layout structuring and styling basics</p>
        </div>
        <div class="timeline-item glass-card" data-aos="fade-right">
          <span class="timeline-date">2022</span>
          <h5>Industrial IoT Intern</h5>
              <p class="job-company">Technomate Edubotics | 2022</p>
              <p class="job-company">● Worked with microcontrollers and IoT sensors</p> 
            <p class="job-company">● Built small automation prototypes using ESP boards and Arduino IDE </p> 
            <p class="job-company">● Learned real-world application of IoT in home automation </p>
        </div>
      </div>
    </div>
  </section>

  <!-- 7. CERTIFICATIONS -->
  <section id="certifications" class="section-padding">
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">Certifications</h2>
      <div class="row g-4">
        <div class="col-md-4" data-aos="zoom-in"><div class="cert-card glass-card">AWS Certification (2024): AWS Academy Graduate - AWS Academy Cloud Foundation, AWS Academy Graduate - AWS 
Academy Machine Learning Foundations </div></div>
        <div class="col-md-4" data-aos="zoom-in" data-aos-delay="100"><div class="cert-card glass-card">30 HTML CSS & JavaScript Projects A Beginner's Guide to JS- Udemy</div></div>
        <div class="col-md-4" data-aos="zoom-in" data-aos-delay="200"><div class="cert-card glass-card">React JS Certification - freeCodeCamp</div></div>
      </div>
    </div>
  </section>

  <!-- 8. ACHIEVEMENTS -->
  <section id="achievements" class="section-padding">
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">Achievements</h2>
      <div class="row text-center g-4">
        <div class="col-6 col-lg-3" data-aos="fade-up"><h3 class="counter" data-target="4">0</h3><p>Projects Completed</p></div>
        <!-- <div class="col-6 col-lg-3" data-aos="fade-up"><h3 class="counter" data-target="8">0</h3><p>Happy Clients</p></div>-->
        <div class="col-6 col-lg-3" data-aos="fade-up"><h3 class="counter" data-target="4">0</h3><p>Internships</p></div>
        <div class="col-6 col-lg-3" data-aos="fade-up"><h3 class="counter" data-target="6">0</h3><p>Certifications</p></div>
      </div>
    </div>
  </section>

  <!-- 9. TESTIMONIALS -->
  <!-- <section id="testimonials" class="section-padding">
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">Testimonials</h2>
      <div class="testimonial glass-card text-center" data-aos="fade-up">
        <img src="https://i.pravatar.cc/80" alt="Client" class="testimonial-img">
        <p>"Chandi delivered exceptional work. The website is fast, beautiful and exactly what we wanted. Highly recommended!"</p>
        <h6>Rahul Sharma - CEO, TechCorp</h6>
      </div>
    </div>
  </section>-->

  <!-- 10. CONTACT -->
  <section id="contact" class="section-padding">
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">Contect Me</h2>
      <div class="row g-4">
        <div class="col-lg-6" data-aos="fade-right">
          <form action="send_mail.php" method="POST">
    
    <div class="form-group">
      <label>Full Name *</label>
      <input type="text" name="name" required placeholder="Enter your name">
    </div>

    <div class="form-group">
      <label>Email Address *</label>
      <input type="email" name="email" required placeholder="Enter your email">
    </div>

    <div class="form-group">
      <label>Subject *</label>
      <input type="text" name="subject" required placeholder="Subject">
    </div>

    <div class="form-group">
      <label>Message *</label>
      <textarea name="message" rows="5" required placeholder="Write your message here..."></textarea>
    </div>

    <button type="submit" name="submit" class="btn">Send Message</button>
  </form>
        </div>
        <div class="col-lg-6" data-aos="fade-left">
          <div class="contact-info">
            <p><i class="fa fa-envelope"></i> deymadhumita18112003@email.com</p>
            <p><i class="fa fa-phone"></i> +91 7679096967</p>
            <p><i class="fa fa-location-dot"></i> Kolkata, West Bengal, India</p>
          </div>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3684.5!2d88.36!3d22.57" width="100%" height="250" style="border:0; border-radius:15px;" allowfullscreen></iframe>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="footer">
    <div class="container text-center">
      <p>© 2026 Madhumita. All Rights Reserved. Designed with <i class="fa fa-heart text-danger"></i></p>
      <div class="social-icons">
        <a href="https://github.com/MadhumitaDey122"><i class="fab fa-github"></i></a>
        <a href="https://www.linkedin.com/in/madhumita-dey-ab2091341"><i class="fab fa-linkedin"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
      </div>
    </div>
  </footer>

  <!-- SCROLL TO TOP -->
  <button id="scrollTop"><i class="fa fa-arrow-up"></i></button>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
  <script src="script.js"></script>
</body>
</html>